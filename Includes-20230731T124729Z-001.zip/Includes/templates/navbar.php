
    
    <!-- START NAVBAR SECTION -->


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>


    
    <header id="header" class="header-section">
    
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="navbar-brand">
                    <img src="Design/images/text logo kl.png" alt="Restaurant Logo" style="width: 150px;">
                </a>
                <div class="d-flex menu-wrap align-items-center">
                    <div class="mainmenu" id="mainmenu">
                        <ul class="nav">
                            <li><a href="index.php#home">HOME</a></li>
                            <li><a href="index.php#menus">MENUS</a></li>
                            <li><a href="index.php#gallery">EVENTS GALLERY</a></li>
                            <li><a href="index.php#about">ABOUT</a></li>
                            <li><a href="index.php#contact">CONTACT</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
   


        <div class="nav-controls top-nav">
            <ul class="nav top-menu">
                <li id="user-btn" class="main-li dropdown" style="background:none;">
                    <div class="dropdown show">
                        <!-- DROPDOWN MENU -->
                        
                     <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                             <a class="dropdown-item" href="users.php?do=Edit&userid=<?php echo $_SESSION['user_id_Reservation'] ?>">
                                <i class="fas fa-user-cog"></i>
                                <span style="padding-left:6px">
                                    Edit Profile
                                </span>

                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i>
                                <span style="padding-left:6px">
                                    Logout
                                </span>
                            </a>
                        </div>
                    </div>
                </li>
            </ul>
        </div> 
</header>




	<div class="header-height" style="height: 120px;"></div> 

    
    <!-- END NAVBAR SECTION -->